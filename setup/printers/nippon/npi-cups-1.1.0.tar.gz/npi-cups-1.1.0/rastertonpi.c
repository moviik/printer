/*
 * Nippon Primex
 *
 * CUPS Filter
 *
 * compile cmd: gcc -Wl,-rpath,/usr/lib -Wall -fPIC -O2 -o rastertocbm1k rastertocbm1k.c -lcupsimage -lcups
 * compile requires cups-devel-1.1.19-13.i386.rpm (version not neccessarily important?)
 * find cups-devel location here: http://rpmfind.net/linux/rpm2html/search.php?query=cups-devel&submit=Search+...&system=&arch=
 */

/*
 * Copyright (C) 2013	Nippon Primex Co. Ltd.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

/*
 * Include necessary headers...
 */


#include	<cups/cups.h>
#include	<cups/ppd.h>
#include	<cups/raster.h>
#include	<stdlib.h>
#include	<fcntl.h>



#ifdef		RPMBUILD

#include	<dlfcn.h>

typedef	cups_raster_t*	(*cupsRasterOpen_fndef)			(int fd,cups_mode_t mode);
typedef	unsigned		(*cupsRasterReadHeader_fndef)	(cups_raster_t *r,cups_page_header_t *h);
typedef	unsigned		(*cupsRasterReadPixels_fndef)	(cups_raster_t *r,unsigned char *p,unsigned len);
typedef	void			(*cupsRasterClose_fndef)		(cups_raster_t *r);

static	cupsRasterOpen_fndef		cupsRasterOpen_fn;
static	cupsRasterReadHeader_fndef	cupsRasterReadHeader_fn;
static	cupsRasterReadPixels_fndef	cupsRasterReadPixels_fn;
static	cupsRasterClose_fndef		cupsRasterClose_fn;

#define	CUPSRASTEROPEN			(*cupsRasterOpen_fn)
#define	CUPSRASTERREADHEADER	(*cupsRasterReadHeader_fn)
#define	CUPSRASTERREADPIXELS	(*cupsRasterReadPixels_fn)
#define	CUPSRASTERCLOSE			(*cupsRasterClose_fn)

typedef	void(*ppdClose_fndef)						(ppd_file_t*ppd);
typedef	ppd_choice_t*(*ppdFindChoice_fndef)			(ppd_option_t*o,constchar*option);
typedef	ppd_choice_t*(*ppdFindMarkedChoice_fndef)	(ppd_file_t*ppd,constchar*keyword);
typedef	ppd_option_t*(*ppdFindOption_fndef)			(ppd_file_t*ppd,constchar*keyword);
typedef	void(*ppdMarkDefaults_fndef)				(ppd_file_t*ppd);
typedef	ppd_file_t*(*ppdOpenFile_fndef)				(constchar*filename);

typedef	void(*cupsFreeOptions_fndef)	(intnum_options,cups_option_t*options);
typedef	int(*cupsParseOptions_fndef)	(constchar*arg,intnum_options,cups_option_t**options);
typedef	int(*cupsMarkOptions_fndef)		(ppd_file_t*ppd,intnum_options,cups_option_t*options);

static	ppdClose_fndefppdClose_fn;
static	ppdFindChoice_fndefppdFindChoice_fn;
static	ppdFindMarkedChoice_fndefppdFindMarkedChoice_fn;
static	ppdFindOption_fndefppdFindOption_fn;
static	ppdMarkDefaults_fndefppdMarkDefaults_fn;
static	ppdOpenFile_fndefppdOpenFile_fn;

static	cupsFreeOptions_fndefcupsFreeOptions_fn;
static	cupsParseOptions_fndefcupsParseOptions_fn;
static	cupsMarkOptions_fndefcupsMarkOptions_fn;

#define	PPDCLOSE			(*ppdClose_fn)
#define	PPDFINDCHOICE		(*ppdFindChoice_fn)
#define	PPDFINDMARKEDCHOICE	(*ppdFindMarkedChoice_fn)
#define	PPDFINDOPTION		(*ppdFindOption_fn)
#define	PPDMARKDEFAULTS 	(*ppdMarkDefaults_fn)
#define	PPDOPENFILE 		(*ppdOpenFile_fn)

#define	CUPSFREEOPTIONS 	(*cupsFreeOptions_fn)
#define	CUPSPARSEOPTIONS	(*cupsParseOptions_fn)
#define	CUPSMARKOPTIONS 	(*cupsMarkOptions_fn)

#else

#define	CUPSRASTEROPEN			cupsRasterOpen
#define	CUPSRASTERREADHEADER	cupsRasterReadHeader
#define	CUPSRASTERREADPIXELS	cupsRasterReadPixels
#define	CUPSRASTERCLOSE			cupsRasterClose

#define	PPDCLOSE				ppdClose
#define	PPDFINDCHOICE			ppdFindChoice
#define	PPDFINDMARKEDCHOICE		ppdFindMarkedChoice
#define	PPDFINDOPTION			ppdFindOption
#define	PPDMARKDEFAULTS			ppdMarkDefaults
#define	PPDOPENFILE				ppdOpenFile

#define	CUPSFREEOPTIONS			cupsFreeOptions
#define	CUPSPARSEOPTIONS		cupsParseOptions
#define	CUPSMARKOPTIONS			cupsMarkOptions

#endif

#define	FALSE 0
#define	TRUE  (!FALSE)

// definitions for printable width
#define	MAX_WIDTH	80
#define	STD_WIDTH	72

struct settings_
{
	float	pageWidth;
	float	pageHeight;

//	int		pageCutType;
//	int		docCutType;


	int		bytesPerScanLine;
	int		bytesPerScanLineStd;

	int		feedSize;
	int		cutterMode;
	int		imagePrintWaitTime;
};

struct command
{
	int		length;
	char*	command;
};

// define printer initialize command
static const struct command printerInitializeCommand =
 { 2, (char[2]){0x1b, '@'} };

// define start page command
const struct command startPageCommand =
 { 2, (char[2]){27, '2'} };

// define end page command
const struct command endPageCommand = {0 ,NULL};

// define end job command
const struct command endJobCommand = {0, NULL};

// define page cut command
const struct command PageCutCommand[2] = {
	{ 2, (char[2]){0x1b, 'm'} },		// Partial Cut
	{ 2, (char[2]){0x1b, 'i'} }			// Full Cut
}
;
// define feed command
const struct command FeedCommand[31] = {
	{ 3, (char[3]){0x1b, 'J', 0} },		//  0mm
	{ 3, (char[3]){0x1b, 'J', 8} },		//  1mm
	{ 3, (char[3]){0x1b, 'J', 16} },	//  2mm
	{ 3, (char[3]){0x1b, 'J', 24} },	//  3mm
	{ 3, (char[3]){0x1b, 'J', 32} },	//  4mm
	{ 3, (char[3]){0x1b, 'J', 40} },	//  5mm
	{ 3, (char[3]){0x1b, 'J', 48} },	//  6mm
	{ 3, (char[3]){0x1b, 'J', 56} },	//  7mm
	{ 3, (char[3]){0x1b, 'J', 64} },	//  8mm
	{ 3, (char[3]){0x1b, 'J', 72} },	//  9mm
	{ 3, (char[3]){0x1b, 'J', 80} },	// 10mm
	{ 3, (char[3]){0x1b, 'J', 88} },	// 11mm
	{ 3, (char[3]){0x1b, 'J', 96} },	// 12mm
	{ 3, (char[3]){0x1b, 'J', 104} },	// 13mm
	{ 3, (char[3]){0x1b, 'J', 112} },	// 14mm
	{ 3, (char[3]){0x1b, 'J', 120} },	// 15mm
	{ 3, (char[3]){0x1b, 'J', 128} },	// 16mm
	{ 3, (char[3]){0x1b, 'J', 136} },	// 17mm
	{ 3, (char[3]){0x1b, 'J', 144} },	// 18mm
	{ 3, (char[3]){0x1b, 'J', 152} },	// 19mm
	{ 3, (char[3]){0x1b, 'J', 160} },	// 20mm
	{ 3, (char[3]){0x1b, 'J', 168} },	// 21mm
	{ 3, (char[3]){0x1b, 'J', 176} },	// 22mm
	{ 3, (char[3]){0x1b, 'J', 184} },	// 23mm
	{ 3, (char[3]){0x1b, 'J', 192} },	// 24mm
	{ 3, (char[3]){0x1b, 'J', 200} },	// 25mm
	{ 3, (char[3]){0x1b, 'J', 208} },	// 26mm
	{ 3, (char[3]){0x1b, 'J', 216} },	// 27mm
	{ 3, (char[3]){0x1b, 'J', 224} },	// 28mm
	{ 3, (char[3]){0x1b, 'J', 232} },	// 29mm
	{ 3, (char[3]){0x1b, 'J', 240} }	// 30mm
};


inline void outputCommand(struct command output)
{
	int	i;

	for(i=0; i < output.length ;i++)
	{
		putchar(output.command[i]);
	}
}

inline int getOptionChoiceIndex(const char * choiceName, ppd_file_t * ppd)
{
	ppd_choice_t	*choice;
	ppd_option_t	*option;

	choice = PPDFINDMARKEDCHOICE(ppd,choiceName);
	if(!choice)
	{
		if(!(option = PPDFINDOPTION(ppd,choiceName)))
		{
			return -1;
		}
		if(!(choice = PPDFINDCHOICE(option,option->defchoice)))
		{
			return -1;
		}
	}
	return atoi(choice->choice);
}

inline void getPageWidthPageHeight(ppd_file_t * ppd, struct settings_ * settings)
{
	ppd_choice_t*	choice;
	ppd_option_t*	option;

	char			width[20];
	char			height[20];
	int				Idx=0;
	char*			pageSize;


	enum{sINIT,sWIDTH,sHEIGHT,sCOMPLETE,sFAIL}	state=sINIT;

	choice = PPDFINDMARKEDCHOICE(ppd,"PageSize");
	if(!choice)
	{
		option = PPDFINDOPTION(ppd,"PageSize");
		choice = PPDFINDCHOICE(option,option->defchoice);
	}

	pageSize=choice->choice;
	while(*pageSize)
	{
		if(state == sINIT)
		{
			if(*pageSize == 'X')
			{
				state = sWIDTH;
				pageSize++;
				continue;
			}
		}
		else if(state == sWIDTH)
		{
			if ((*pageSize >= '0') && (*pageSize <= '9'))
			{
				width[Idx++] = *pageSize++;
				continue;
			}
			else if(*pageSize == 'D')
			{
				width[Idx++] = '.';
				pageSize++;
				continue;
			}
			else if(*pageSize == 'M')
			{
				pageSize++;
				continue;
			}
			else if(*pageSize == 'Y')
			{
				state = sHEIGHT;
				width[Idx] = 0;
				Idx = 0;
				pageSize++;
				continue;
			}
		}
		else if(state == sHEIGHT)
		{
			if((*pageSize >= '0') && (*pageSize <= '9'))
			{
				height[Idx++] = *pageSize++;
				continue;
			}
			else if(*pageSize == 'D')
			{
				height[Idx++] = '.';
				pageSize++;
				continue;
			}
			else if(*pageSize == 'M')
			{
				height[Idx] = 0;
				state = sCOMPLETE;
				break;
			}
		}
		state = sFAIL;
		break;
	}

	if(state == sCOMPLETE)
	{
		settings->pageWidth  = atof(width);
		settings->pageHeight = atof(height);
	}
	else
	{
		settings->pageWidth  = 0;
		settings->pageHeight = 0;
	}
}

int initializeSettings(char * commandLineOptionSettings, struct settings_ * settings)
{
	ppd_file_t*		ppd;
	cups_option_t*	options		= NULL;
	int				numOptions;

	ppd = PPDOPENFILE(getenv("PPD"));
	if(ppd == NULL)
	{
		fprintf(stderr, "INFO: PPD(%s) open error\n", getenv("PPD"));
		return FALSE;
	}
	PPDMARKDEFAULTS(ppd);
	numOptions = CUPSPARSEOPTIONS(commandLineOptionSettings, 0, &options);
	if((numOptions != 0) && (options != NULL))
	{
		CUPSMARKOPTIONS(ppd, numOptions, options);
		CUPSFREEOPTIONS(numOptions, options);
	}
	memset(settings, 0, sizeof(struct settings_));
//	settings->pageCutType			= getOptionChoiceIndex("PageCutType",			ppd);
//	settings->docCutType			= getOptionChoiceIndex("DocCutType",			ppd);
	settings->feedSize				= getOptionChoiceIndex("FeedMode",				ppd);
	settings->cutterMode			= getOptionChoiceIndex("CutterMode",			ppd);
	settings->imagePrintWaitTime	= getOptionChoiceIndex("ImagePrintWaitTime",	ppd);
	settings->bytesPerScanLine		= MAX_WIDTH;
	settings->bytesPerScanLineStd	= STD_WIDTH;
	getPageWidthPageHeight(ppd, settings);
	PPDCLOSE(ppd);
	return TRUE;
}

void jobSetup(struct settings_ settings)
{
	outputCommand(printerInitializeCommand);
}

void pageSetup(struct settings_ settings, cups_page_header_t header)
{
	outputCommand(startPageCommand);
}

void feedSet(struct settings_ settings)
{
	if(settings.feedSize != 0)
	{
		outputCommand(FeedCommand[settings.feedSize]);	// Feed
	}
}

void cutPage(struct settings_ settings)
{
	switch(settings.cutterMode)
	{
	case 3:
	case 4:
		outputCommand(PageCutCommand[0]);		// Partial Cut
		break;
	case 5:
		outputCommand(PageCutCommand[1]);		// Full Cut
		break;
	default:
		break;
	}
}

void cutJob(struct settings_ settings)
{
	switch(settings.cutterMode)
	{
	case 1:
	case 3:
		outputCommand(PageCutCommand[0]);		// Partial Cut
		break;
	case 2:
	case 4:
	case 5:
		outputCommand(PageCutCommand[1]);		// Full Cut
		break;
	default:
		break;
	}
}

void endPage(struct settings_ settings)
{
	outputCommand(endPageCommand);
}

void endJob(struct settings_ settings)
{
	outputCommand(endJobCommand);
}

void waitTimer(struct settings_ settings)
{
	unsigned int TimerSize;

	TimerSize = settings.imagePrintWaitTime * 1000;
	if(TimerSize != 0)
	{
		usleep((useconds_t)TimerSize);	// msec
	}
}
#define	GET_LIB_FN_OR_EXIT_FAILURE(fn_ptr,lib,fn_name)										\
{																							\
	fn_ptr = dlsym(lib,fn_name);															\
	if ( (dlerror()) )																		\
	{																						\
		fputs("ERROR: required fn not exported from dynamically loaded libary\n", stderr);	\
		if(libCupsImage)																	\
		{																					\
			dlclose(libCupsImage);															\
		}																					\
		if(libCups)																			\
		{																					\
			dlclose(libCups);																\
		}																					\
		return EXIT_FAILURE;																\
	}																						\
}

#ifdef	RPMBUILD
#define	CLEANUP 			\
{							\
	if(rasterData)			\
	{						\
		free(rasterData);	\
	}						\
	CUPSRASTERCLOSE(ras);	\
	if(fd)					\
	{						\
		close(fd);			\
	}						\
	dlclose(libCupsImage);	\
	dlclose(libCups);		\
}
#else
#define	CLEANUP 			\
{							\
	if(rasterData)			\
	{						\
		free(rasterData);	\
	}						\
	CUPSRASTERCLOSE(ras);	\
	if(fd)					\
	{						\
		close(fd);			\
	}						\
}
#endif

int main(int argc, char *argv[])
{
	int 				fd;							/* File descriptor providing CUPS raster data				*/
	cups_raster_t		*ras; 						/* Raster stream for printing								*/
	cups_page_header_t	header; 					/* CUPS Page header 										*/

	int					x;							/* Horizontal position 0 <= x <=header.cupsBytesPerLine*8	*/
	int	 				y;							/* Vertical position in page 0 <= y <=header.cupsHeight		*/
	int					page = 0;					/* Current page												*/

	unsigned char		*rasterData = NULL;			/* Pointer to raster data buffer							*/

	struct settings_	settings;					/* Configuration settings									*/

	int c;

#ifdef RPMBUILD
	void	*libCupsImage;							/* Pointer to libCupsImage library							*/
	void	*libCups;								/* Pointer to libCups library								*/
	FILE	*f;

	libCups = dlopen("libcups.so", RTLD_NOW|RTLD_GLOBAL);
	if(!libCups)
	{
		fputs("ERROR: libcups.so load failure\n", stderr);
		return EXIT_FAILURE;
	}

	libCupsImage=dlopen("libcupsimage.so", RTLD_NOW|RTLD_GLOBAL);
	if(!libCupsImage)
	{
		fputs("ERROR: libcupsimage.so load failure\n", stderr);
		dlclose(libCups);
		return EXIT_FAILURE;
	}

	GET_LIB_FN_OR_EXIT_FAILURE(ppdClose_fn, 			libCups,	  "ppdClose"			 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindChoice_fn,		libCups,	  "ppdFindChoice"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindMarkedChoice_fn,	libCups,	  "ppdFindMarkedChoice"  );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdFindOption_fn,		libCups,	  "ppdFindOption"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdMarkDefaults_fn,		libCups,	  "ppdMarkDefaults" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(ppdOpenFile_fn,			libCups,	  "ppdOpenFile" 		 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsFreeOptions_fn,		libCups,	  "cupsFreeOptions" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsParseOptions_fn, 	libCups,	  "cupsParseOptions"	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsMarkOptions_fn,		libCups,	  "cupsMarkOptions" 	 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterOpen_fn,		libCupsImage, "cupsRasterOpen"		 );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterReadHeader_fn, libCupsImage, "cupsRasterReadHeader" );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterReadPixels_fn, libCupsImage, "cupsRasterReadPixels" );
	GET_LIB_FN_OR_EXIT_FAILURE(cupsRasterClose_fn,		libCupsImage, "cupsRasterClose" 	 );
#endif

	if((argc < 6) || (argc > 7))
	{
		fputs("ERROR: rastertocbm1k job-id user title copies options [file]\n", stderr);
		#ifdef RPMBUILD
			dlclose(libCupsImage);
			dlclose(libCups);
		#endif
		return EXIT_FAILURE;
	}
	if(argc == 7)
	{
		if((fd = open(argv[6], O_RDONLY)) == -1)
		{
			perror("ERROR: Unable to open raster file - ");
			sleep(1);
			#ifdef RPMBUILD
				dlclose(libCupsImage);
				dlclose(libCups);
			#endif
			return EXIT_FAILURE;
		}
	}
	else
	{
		fd=0;
	}

	if(initializeSettings(argv[5], &settings) == FALSE)
	{
		#ifdef RPMBUILD
			dlclose(libCupsImage);
			dlclose(libCups);
		#endif
		return EXIT_FAILURE;
	}
	jobSetup(settings);
	ras = CUPSRASTEROPEN(fd, CUPS_RASTER_READ);

	while( CUPSRASTERREADHEADER(ras, &header) )
	{
		if( (header.cupsHeight == 0) || (header.cupsBytesPerLine == 0) )
		{
			break;
		}
		if(rasterData == NULL)
		{
			rasterData = malloc(header.cupsBytesPerLine * header.cupsHeight);
			if(rasterData == NULL)
			{
				CLEANUP;
				return EXIT_FAILURE;
			}
		}

		if(page > 0)
		{
			feedSet(settings);
			cutPage(settings);
		}

		pageSetup(settings, header);
		page++;
		fprintf(stderr,"PAGE: %d %d\n", page, header.NumCopies);

        if (header.cupsBytesPerLine <= settings.bytesPerScanLine)
        {
        	settings.bytesPerScanLine = header.cupsBytesPerLine;
        }
        else
        {
        	settings.bytesPerScanLine = settings.bytesPerScanLineStd;
        }

		// Read data
		if( CUPSRASTERREADPIXELS(ras, rasterData, header.cupsBytesPerLine * header.cupsHeight ) < 1 )
		{
			break;
		}

		// Output Data
		putchar(0x1b); // [ESC b n1 n2 n3 Dn]
		putchar('b');
		putchar(header.cupsBytesPerLine);
		putchar(header.cupsHeight % 256);
		putchar(header.cupsHeight / 256);
		for(y=0; y < header.cupsHeight ;y++)
		{
			for(x=0; x < header.cupsBytesPerLine ;x++)
			{
				putchar(rasterData[ (y * header.cupsBytesPerLine) + x ]);
			}
			waitTimer(settings);
		}
		putchar(0x1b); // [ESC J n(0x00)]
		putchar('J');
		putchar(0);

		endPage(settings);
	}
	feedSet(settings);
	cutJob(settings);
	endJob(settings);
	for(c=0; c < 1024*4 ;c++)
	{
		putchar(0);
	}
	usleep(5000000); // 5sec
	CLEANUP;
	if(page == 0)
	{
		fputs("ERROR: No pages found!\n", stderr);
	}
	else
	{
		fputs("INFO: Ready to print.\n", stderr);
	}
	return(page == 0)?EXIT_FAILURE:EXIT_SUCCESS;
}

// end of rastertocbm1k.c
